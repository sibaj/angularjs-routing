var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "view/main.html",
        controller:'mainController'
    })
    .when("/red", {
        templateUrl : "view/red.html",
        controller:'redController'
    })
    .when("/green", {
        templateUrl : "view/green.html",
        controller:'greenController'
    })
    .when("/blue", {
        templateUrl : "view/blue.html",
        controller:'blueController'
    });
});