app.controller("greenController",function($scope){
    $scope.message="inside greenController";
})