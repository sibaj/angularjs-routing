app.controller("redController",function($scope){
    $scope.message="inside redController";
})