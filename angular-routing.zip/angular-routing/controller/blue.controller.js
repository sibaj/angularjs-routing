app.controller("blueController",function($scope){
    $scope.message="inside blueController";
})