app.controller("mainController",function($scope){
    $scope.message="inside mainController";
})

